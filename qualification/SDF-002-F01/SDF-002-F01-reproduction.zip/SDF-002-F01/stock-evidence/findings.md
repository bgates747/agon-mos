# SDF-002-F01 — Stock MOS write-completion timeout

## Verdict

**Reproduced under device-boundary fault injection with unchanged stock MOS
3.0.2.** After accepting the write data, MOS took its busy-completion timeout
branch but returned SD_SUCCESS and FatFS RES_OK. Normal and rejected-data
controls behaved as expected. This confirms the control-flow/error-reporting
finding under the supplied response sequence; it does not demonstrate a
real-card failure, physical data loss or successful high-level synchronization.

MOS and VDP were not modified. No fix, external issue/PR or TRS-80 code change
was made. Physical hardware remains the authority for actual card behavior.

## Controls and observed results

| Trial | Card-model responses | Busy timeout reached | SD result A | disk_write result HL |
| --- | --- | --- | --- | --- |
| Unmodified Fab control | Command 00, data 05, ready 01 | No | 00 | 000000 / RES_OK |
| Instrumented normal | Command 00, data 05, ready 01 | No | 00 | 000000 / RES_OK |
| Injected persistent busy | Command 00, data 05, then repeated 00 | Yes | 00 | 000000 / RES_OK |
| Injected data rejection | Command 00, data 0D | No | 01 | 000001 / RES_ERROR |

Each trial starts with an independent copy of the same raw image and writes
one 512-byte block to LBA 1, outside the partition starting at LBA 2048.
The probe enters the release's disk_write routine at 00A73F using its verified
ZDS stack ABI. This is an internal-call qualification probe, not a portable
public-API case. The C++ caller records the returned DRESULT via an assembly
adapter. All processes exited zero and were closed. All non-test-sector bytes
were unchanged. There was exactly one observed write-command response per trial.

## Independent source and released-binary trace

1. At 00A2EB, SD_writeSingleBlock has received CMD24 response A=00 and is about
   to push AF. The debugger observed A=00 in all four controls.
2. At 00A33E, the released bytes DD 77 FF store accepted token 05 at IX-1.
   At the following 00A341 breakpoint, the captured token byte was 05.
3. The completion timer loads BC=004650 (18000) with divider 256. The source
   uses MASTERCLOCK/1000/256*250: nominally 250 ms, not a host-time measurement.
   MOS polls timer control port 80h through IN0/RLA and JR NC.
4. Under persistent busy, the debugger reached 00A366, the timeout-only jump.
   AF was 188D: carry was set after the timer-status RLA. It did not reach the
   normal ready branch at 00A368. The unmodified timer model drove expiry;
   no timer register, MOS token, result register or PC was forced.
5. At 00A379, after POP AF, A was restored to 00 and IX-1 remained 05.
   At 00A2D2, _SD_writeBlocks returned A=00. Its checks require only the restored
   command response zero and token 05 before decrementing the one-block count.
6. At 00A770, disk_write returned HL=000000, implementing its source mapping
   from SD_SUCCESS to RES_OK. The probe also recorded zero.
7. The rejected-data control retained token FF, returned A=01 from
   _SD_writeBlocks and HL=000001 from disk_write. This demonstrates that the
   observation path distinguishes success from a reported error.

The source comment on the normal-ready path says to set token to zero, but the
actual instruction at 00A369 is LD A,(IX-1), a load rather than a store.
Both source and released bytes agree. The timeout diagnosis does not depend on
that misleading comment: the accepted token survives the timeout path itself.

disk_ioctl unconditionally returns RES_OK in the pinned source. This trial did
not call it, f_sync, f_close, a later read, or a multi-sector write. It establishes
neither their complete runtime behavior nor an application persistence guarantee.
The separately raised RTC/interrupt dependency was not investigated here.

## Emulator fidelity and interpretation

The ordinary Fab SD model immediately writes 512 payload bytes to its host image
and queues accepted token 05 followed by ready byte 01. It has no prolonged
write-busy phase, so ordinary successful save/reload tests cannot exercise F01.

The qualification copy changes only spi_sdcard.rs. For sector 1 it selects normal,
persistent-busy or rejection responses through MOS02_SD_MODE. Responses are
injected at SPI_RBR reads; actual MOS instructions traverse the SD/SPI path.
Raw --sdcard-img disables hostfs interception in set_sdcard_image. The unchanged
timer implementation advances from emulated CPU cycles; --precise-interrupts
was enabled and -u disabled wall-clock throttling. Its timing and SD model are
not a physical-card conformance model. Logs retain the first response bytes and
periodic repeated-busy counts (through at least response 90112), not every busy
byte as a separate log line.

The model's eager host-file write was intentionally retained in every mode,
including rejection and busy. Thus all four image sectors contain the payload;
that is an emulator implementation detail, not proof of physical persistence,
eventual completion or a claim that a rejected real-card write commits data.
No card power cut, CPU reset or physical-device behavior was reproduced.

## Exact pins

- MOS source/tag: AgonPlatform v3.0.2,
  8336409351ee5314e02801a7b72a4f1bb5282519.
- MOS binary SHA-256:
  d564243283972690933a4554296ad6202ca4ef54572279533a942960846bebae.
- Fab source: 1.2.4, 194a5e44c36a8bb886dae1741b01c6e7a1e5ede7.
- Instrumented emulator SHA-256:
  a1f7e013b53d9dbb450856adb1a11ed64ac3ca6a2fcf7e7355fdf3cba7dd21fa.
- Unmodified emulator SHA-256:
  a96ca0e6f5f51ba6b750bd6fcf96efcaed88e61c431171f79a7db5f29877f17e.
- Unchanged VDP SHA-256:
  bc7a8a6a28e176c9679c96de4bda16010b765074ec8ba155fccde189c1051955.

pins.json also records the MOS map, source-file hashes matching the handoff,
unchanged timer source, probe binary/map and injection source. The released MOS
checkout remained clean. Qualification source is isolated under this project's
.emulator/mos02; no upstream checkout was edited.

## Reproduce and excluded attempts

Follow README.md in this task directory. observe.py performs only breakpoint,
register/memory and disassembly observations; verify.py independently checks
all four outcomes, token preservation and image boundaries. Evidence is in
evidence.tar.gz, with a content manifest and archive SHA-256.

The initial inspect run stopped before the write and was excluded from runtime
control counts. Binary inspection showed that disk_write returns DRESULT in HL,
so the probe's adapter was corrected to copy L to A before the write trials.
No write result from the earlier adapter was used. An initial build command had
an incorrect log-directory path and did not run; its corrected build succeeded.
The final setup.py packages the executed setup steps; it was syntax-checked,
not rerun over the preserved trial directory.

## Remaining uncertainty and disposition

Hardware must establish whether and under what conditions a real card remains
busy past this interval, whether it later completes, and how later operations
behave. Do not infer data loss, card compliance or a successful application sync.
The status-reporting finding is sufficient to reject an unconditional claim that
this release reports every write-completion timeout as an error.

Findings are ready for the Author and requesting project to review. No firmware
patch is proposed or authorized by this report.
