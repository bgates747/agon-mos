use std::io::{Read, Seek, SeekFrom, Write};

pub struct SpiSdcard {
    in_buf: Vec<u8>,
    out_buf: Vec<u8>,
    spi_sr: u8,
    check_pattern: u8,
    image: Option<std::fs::File>,
    next_write_sector: Option<usize>,
    next_write_started: bool,
    f01_mode: String,
    f01_busy: bool,
    f01_selected: bool,
    f01_reads: u64,
}

impl SpiSdcard {
    pub fn new() -> Self {
        SpiSdcard {
            spi_sr: 0,
            in_buf: vec![],
            out_buf: vec![],
            check_pattern: 0,
            image: None,
            next_write_sector: None,
            next_write_started: false,
            f01_mode: std::env::var("MOS02_SD_MODE").unwrap_or("normal".into()),
            f01_busy: false,
            f01_selected: false,
            f01_reads: 0,
        }
    }

    pub fn set_image_file(&mut self, file: Option<std::fs::File>) {
        self.image = file;
    }

    pub fn recv_byte(&mut self, val: u8) {
        if let Some(image) = self.image.as_mut() {
            // 0x80 means transfer finished (immediate on the emulator)
            self.spi_sr = 0x80;
            if self.f01_busy { return; }

            if (self.next_write_sector.is_none() || !self.next_write_started)
                && self.in_buf.len() == 0
                && val == 255
            {
                // init sequence. ignore
            } else if self.next_write_sector.is_some() && !self.next_write_started && val == 254 {
                // 254 is the 'SD_START_TOKEN'
                self.next_write_started = true;
                return;
            } else {
                self.in_buf.push(val);
            }

            if self.next_write_started {
                if self.in_buf.len() == 512 {
                    let sector = self.next_write_sector.unwrap();
                    self.next_write_started = false;
                    self.next_write_sector = None;
                    //println!("WRITE!!!!!!!!! sector {}, {:?}", sector, self.in_buf);
                    match image
                        .seek(SeekFrom::Start(sector as u64 * 512))
                        .and_then(|_| image.write_all(&self.in_buf))
                    {
                        Ok(_) => {}
                        Err(e) => {
                            eprintln!("Error reading SDcard image: {:?}", e);
                        }
                    };

                    self.in_buf.clear();
                    if sector == 1 {
                        assert!(["normal","busy","reject"].contains(&self.f01_mode.as_str()));
                        self.f01_selected=true;
                        self.f01_busy=self.f01_mode=="busy";
                        self.out_buf.push(if self.f01_mode=="reject" {0x0d} else {5});
                        if !self.f01_busy { self.out_buf.push(1); }
                        eprintln!("F01 payload=512 sector=1 mode={} image_write=completed token={:02x}",self.f01_mode,if self.f01_mode=="reject"{0x0d}else{5});
                    } else { self.out_buf.push(5); self.out_buf.push(1); }
                }
                return;
            }

            //println!("SPI in buffer contains {:?}", self.in_buf);
            //println!("SPI out buffer len {}", self.out_buf.len());

            const CMD0: u8 = 0 | 0x40;
            const CMD8: u8 = 8 | 0x40;
            const CMD55: u8 = 55 | 0x40;
            const ACMD41: u8 = 41 | 0x40;
            const CMD58: u8 = 58 | 0x40;
            const CMD17: u8 = 17 | 0x40;
            const CMD24: u8 = 24 | 0x40;

            // Try to match a command
            if self.in_buf.len() >= 6 {
                match self.in_buf[..] {
                    // CMD0 (go to idle. part of init)
                    [CMD0, _a3, _a2, _a1, _a0, _crc, ..] => {
                        self.in_buf.drain(0..6);
                        self.out_buf.push(1); // OK
                    }
                    // CMD8 (interface condition)
                    [CMD8, _a3, _a2, _a1, check_pattern, _crc, ..] => {
                        self.check_pattern = check_pattern;
                        self.in_buf.drain(0..6);
                        self.out_buf.extend_from_slice(&[1, 0, 0, 1, check_pattern]);
                    }
                    // CMD55
                    [CMD55, _a3, _a2, _a1, _a0, _crc, ..] => {
                        self.out_buf.push(1); // OK
                        self.in_buf.drain(0..6);
                    }
                    // ACMD41
                    [ACMD41, _a3, _a2, _a1, _a0, _crc, ..] => {
                        self.out_buf.push(0); // In idle state
                        self.in_buf.drain(0..6);
                    }
                    // CMD58
                    [CMD58, _a3, _a2, _a1, _a0, _crc, ..] => {
                        self.out_buf.push(0); // v2.0+ standard capacity
                        self.in_buf.drain(0..6);
                    }
                    // CMD17
                    [CMD17, sec3, sec2, sec1, sec0, _crc, ..] => {
                        let sector = sec0 as usize
                            + ((sec1 as usize) << 8)
                            + ((sec2 as usize) << 16)
                            + ((sec3 as usize) << 24);
                        //println!("GOT CMD17. read sector {}", sector);
                        self.in_buf.drain(0..6);
                        self.out_buf.push(0);
                        self.out_buf.push(0xfe);
                        let mut buf = [0u8; 512];
                        match image
                            .seek(SeekFrom::Start(sector as u64 * 512))
                            .and_then(|_| image.read_exact(&mut buf))
                        {
                            Ok(_) => {}
                            Err(e) => {
                                eprintln!("Error reading SDcard image: {:?}", e);
                            }
                        };
                        self.out_buf.extend_from_slice(&buf);
                        // 2 crc bytes that mos ignores
                        self.out_buf.push(0);
                        self.out_buf.push(0);
                    }
                    // CMD24
                    [CMD24, sec3, sec2, sec1, sec0, _crc, ..] => {
                        let sector = sec0 as usize
                            + ((sec1 as usize) << 8)
                            + ((sec2 as usize) << 16)
                            + ((sec3 as usize) << 24);
                        self.next_write_sector = Some(sector);
                        self.next_write_started = false;
                        self.in_buf.drain(0..6);
                        if sector==1 {eprintln!("F01 CMD24 sector=1 command_response=00");}
                        self.out_buf.push(0);
                    }
                    _ => {
                        eprintln!(
                            "Unknown SDcard command {:?}: {:?}",
                            self.in_buf.get(0).and_then(|v| Some(*v & !0x40)),
                            self.in_buf
                        );
                        // drop the command
                        self.in_buf.clear();
                    }
                }
            }
        }
    }

    pub fn send_byte(&mut self) -> Option<u8> {
        let value=if !self.out_buf.is_empty() {Some(self.out_buf.remove(0))}
            else if self.f01_busy {Some(0)} else {None};
        if self.f01_selected {
            self.f01_reads+=1;
            if self.f01_reads<=8 || self.f01_reads%4096==0 {
                eprintln!("F01 response_index={} value={:02x} persistent_busy={}",self.f01_reads,value.unwrap_or(255),self.f01_busy);
            }
        }
        value
    }

    pub fn get_spi_status_register(&mut self) -> u8 {
        let sr = self.spi_sr;
        self.spi_sr = 0;
        sr
    }

    pub fn get_spi_control_register(&mut self) -> u8 {
        0
    }
}
