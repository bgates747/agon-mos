extern "C" {
volatile unsigned char result=255;
unsigned char write_sector();
void probe_done();
unsigned char buffer[512];
}
int main(){for(unsigned i=0;i<512;++i)buffer[i]=(i*37+11)&255;result=write_sector();probe_done();return 0;}
