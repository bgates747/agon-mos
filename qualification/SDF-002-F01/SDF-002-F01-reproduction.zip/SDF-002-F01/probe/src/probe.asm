 .assume adl=1
 .section .text
 .global _write_sector
 .global _probe_done
 .extern _buffer
_write_sector:
 push ix
 push iy
 ld hl,1
 push hl
 ld hl,0
 push hl
 ld hl,1
 push hl
 ld hl,_buffer
 push hl
 ld hl,0
 push hl
 call 00a73fh
 pop bc
 pop bc
 pop bc
 pop bc
 pop bc
 ld a,l
 pop iy
 pop ix
 ret
_probe_done:
 ret
