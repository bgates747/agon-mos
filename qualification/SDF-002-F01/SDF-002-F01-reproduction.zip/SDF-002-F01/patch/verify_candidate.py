"""Validate retained candidate controls without rerunning or altering firmware."""
from pathlib import Path
import json,re,hashlib
ROOT=Path(__file__).resolve().parents[4];base=ROOT/'.emulator/mos02'
manifest=json.loads((base/'candidate-build/candidate.json').read_text())
def reg(event,name):return int(re.search(name+r':([0-9a-fA-F]+)',event['registers'])[1],16)
sha=lambda b:hashlib.sha256(b).hexdigest()
stock=(ROOT/'.emulator/firmware/mos_platform.bin').read_bytes()
candidate=(base/'candidate-build/mos-3.0.2-f01-candidate.bin').read_bytes()
assert sha(stock)==manifest['stock_sha256'] and sha(candidate)==manifest['candidate_sha256']
original=(base/'control-base.img').read_bytes();rows=[]
for mode in ['normal','busy','reject','stock']:
 folder=base/('candidate-'+mode)
 d=json.loads((folder/'result.json').read_text());identity=json.loads((folder/'identity.json').read_text())
 assert d['exit_code']==0 and identity['mos']==manifest['candidate_sha256']
 assert identity['vdp']==sha((ROOT/'.emulator/firmware/vdp_platform.so').read_bytes())
 points={int(e['pc'],16):e for e in d['events'] if 'pc' in e}
 expected=int(mode in ['busy','reject'])
 assert reg(points[0xa2eb],'AF')>>8==0
 assert (0xa366 in points)==(mode=='busy')
 assert (0xa368 in points)==(mode=='busy') # now the timeout's store instruction
 token=points[0xa379]['frame'][2]
 assert token=={'normal':5,'stock':5,'busy':0,'reject':255}[mode]
 assert reg(points[0xa379],'AF')>>8==0
 assert reg(points[0xa2d2],'AF')>>8==expected and reg(points[0xa770],'HL')==expected
 assert next(e['result'][0] for e in d['events'] if 'result' in e)==expected
 if mode=='busy':assert reg(points[0xa366],'AF')&1
 image=(folder/'sd.img').read_bytes()
 assert len(image)==len(original) and image[:512]==original[:512] and image[1024:]==original[1024:]
 assert image[512:1024]==bytes((i*37+11)&255 for i in range(512))
 rows.append({'mode':mode,'token':token,'timeout':mode=='busy','sd_status':expected,'disk_status':expected,'result_sha256':sha((folder/'result.json').read_bytes()),'image_sha256':sha(image)})
result={'passed':True,'candidate':manifest,'controls':rows,'full_zds_build':False,'hardware_tested':False,'later_sync_or_reads_tested':False}
(base/'candidate-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASSED: four candidate controls; busy/reject return errors, normal succeeds; image boundaries preserved.')
