; Instruction-equivalent expansion of the modified 3.0.2 source window.
; Linked at 0xA358; timer/read helper addresses remain from the pinned release.
 .assume adl=1
 .section .text
busy:
 call 00a51fh
 cp a,0
 jr nz,reset
 in0 a,(080h)
 rla
 jr nc,busy
 ld a,0
 ld (ix-1),a
 nop
reset:
