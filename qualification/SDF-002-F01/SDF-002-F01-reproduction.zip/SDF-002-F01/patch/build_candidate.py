"""Build a qualification-only exact-release overlay; never edits input firmware."""
from pathlib import Path
import argparse,hashlib,json,subprocess,shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[3]
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
stock=ROOT/'.emulator/firmware/mos_platform.bin';data=stock.read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(data)=='d564243283972690933a4554296ad6202ca4ef54572279533a942960846bebae'
vendor=ROOT/'vendor/agon-mos/3.0.2'
pins=json.loads((vendor/'UPSTREAM.json').read_text())
for name,digest in pins['files'].items():assert sha((vendor/name).read_bytes())==digest
(out/'source/src').mkdir(parents=True)
shutil.copy2(vendor/'src/sd.asm',out/'source/src/sd.asm')
with (HERE/'sd-timeout.patch').open('rb') as patch:
 subprocess.run(['patch','--binary','-p1'],cwd=out/'source',stdin=patch,check=True)
tool=Path('/home/smith/Agon/agondev/release/bin')
subprocess.run([str(tool/'ez80-none-elf-as'),'-march=ez80+adl',str(HERE/'window.asm'),'-o',str(out/'window.o')],check=True)
subprocess.run([str(tool/'ez80-none-elf-ld'),'-e','0xa358','-Ttext=0xa358','-o',str(out/'window.elf'),str(out/'window.o')],check=True)
subprocess.run([str(tool/'ez80-none-elf-objcopy'),'-O','binary',str(out/'window.elf'),str(out/'window.bin')],check=True)
replacement=(out/'window.bin').read_bytes()
old=bytes.fromhex('cd1fa500fe002008ed38801730f21804afdd7eff')
expected=bytes.fromhex('cd1fa500fe00200ced38801730f23e00dd77ff00')
assert data[0xa358:0xa36c]==old and replacement==expected
fixed=data[:0xa358]+replacement+data[0xa36c:]
assert len(fixed)==len(data) and fixed[:0xa358]==data[:0xa358] and fixed[0xa36c:]==data[0xa36c:]
(out/'mos-3.0.2-f01-candidate.bin').write_bytes(fixed)
with (out/'disassembly.txt').open('w') as log:subprocess.run([str(tool/'ez80-none-elf-objdump'),'-d',str(out/'window.elf')],stdout=log,check=True)
manifest={'qualification_only':True,'full_zds_build':False,'hardware_tested':False,'stock_sha256':sha(data),'candidate_sha256':sha(fixed),'source_patch_sha256':sha((HERE/'sd-timeout.patch').read_bytes()),'patched_source_sha256':sha((out/'source/src/sd.asm').read_bytes()),'window_address':'0xa358','window_before':old.hex(),'window_after':replacement.hex(),'changed_offsets':[hex(i) for i,(a,b) in enumerate(zip(data,fixed)) if a!=b],'assembler_sha256':sha((tool/'ez80-none-elf-as').read_bytes())}
(out/'candidate.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
