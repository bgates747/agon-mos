from pathlib import Path
import sys,os,pty,select,subprocess,time,re,json,shutil,hashlib
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'agents'))
from run_startup import drain_exit
from run_smoke import ANSI,symbol
from check_capture import memory
mode=sys.argv[1]
candidate='--candidate' in sys.argv[2:]
config=json.loads(Path(sys.argv[sys.argv.index('--config')+1]).read_text()) if '--config' in sys.argv else None
out=Path(config['output']) if config else ROOT/'.emulator/mos02'/(('candidate-' if candidate else '')+mode)
out.mkdir(exist_ok=False)
shutil.copy2(Path(config['image']) if config else ROOT/'.emulator/mos02/control-base.img',out/'sd.img')
profile=Path(config['profile']) if config else ROOT/('.emulator' if mode=='stock' else '.emulator/mos02/profile')
if candidate and not config:profile=ROOT/'.emulator/mos02'/('candidate-profile-stock' if mode=='stock' else 'candidate-profile')
maps=Path(config['probe_map']).read_text() if config else (ROOT/'corrections/SDF-002-F01/reproducer/probe/bin/sd-timeout-probe.map').read_text()
done=symbol(maps,'_probe_done');result_address=symbol(maps,'_result');entry=symbol(maps,'_write_sector')
env=os.environ.copy();env.update(SDL_VIDEODRIVER='dummy',SDL_AUDIODRIVER='dummy',MOS02_SD_MODE='normal' if mode in ['inspect','stock'] else mode)
identity={name:hashlib.sha256((profile/path).read_bytes()).hexdigest() for name,path in [('emulator','fab-agon-emulator.bin'),('mos','mos_platform.bin'),('vdp','firmware/vdp_platform.so')]}
identity['image_before']=hashlib.sha256((out/'sd.img').read_bytes()).hexdigest()
identity['candidate_overlay']=candidate
if config:identity['full_source_config']=config
identity['timing']='--precise-interrupts -u; stock timer model; no physical timing claim'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
master,slave=pty.openpty();raw=bytearray();events=[]
proc=subprocess.Popen(['./fab-agon-emulator','--sdcard-img',str(out/'sd.img'),'--renderer','sw','--vdp',str(profile/'firmware/vdp_platform.so'),'--precise-interrupts','-u','-d','-b','0'],cwd=profile,env=env,stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
os.close(slave)
def wait(off):
 deadline=time.monotonic()+90
 while time.monotonic()<deadline:
  if b'>> ' in ANSI.sub(b'',bytes(raw[off:])):return
  if select.select([master],[],[],.1)[0]:
   try:raw.extend(os.read(master,65536))
   except OSError:raise RuntimeError('PTY closed')
  if proc.poll() is not None:raise RuntimeError('emulator exited')
 raise TimeoutError('debugger wait')
def cmd(text):
 off=len(raw);os.write(master,(text+'\n').encode());wait(off)
 return ANSI.sub(b'',bytes(raw[off:])).decode(errors='replace').replace('\r','')
try:
 wait(0)
 if mode=='inspect':
  for a,b in [(0xa2a8,0xa3e0),(0xa73f,0xa7a5)]:
   events.append({'disassembly':cmd(f'dis24 ${a:x} ${b:x}')})
  cmd(f'break ${entry:x}')
 else:
  cmd(f'break ${done:x}')
  for address in (config['breakpoints'] if config else [0xa2eb,0xa341,0xa366,0xa368,0xa374,0xa379,0xa2d2,0xa770]):
   cmd(f'break ${address:x}')
 cmd('delete $0')
 for step in range(20):
  stopped=cmd('c');regs=cmd('registers')
  pc=int(re.search(r'PC=([0-9a-fA-F]+)',regs)[1],16)
  ix=int(re.search(r'IX:([0-9a-fA-F]+)',regs)[1],16)
  event={'pc':hex(pc),'stop':stopped,'registers':regs}
  if mode!='inspect' and pc!=done:
   event['frame_address']=hex(ix-3)
   event['frame']=list(memory(cmd(f'mem ${ix-3:x} 24'),ix-3,24))
  events.append(event)
  if pc==(entry if mode=='inspect' else done):break
 else:raise RuntimeError('unexpected extra breakpoint')

 if mode!='inspect':events.append({'result':list(memory(cmd(f'mem ${result_address:x} 1'),result_address,1))})
 events.append({'registers':cmd('registers')})
 os.write(master,b'exit\n');code=drain_exit(proc,master,raw)
 (out/'result.json').write_text(json.dumps({'mode':mode,'events':events,'exit_code':code},indent=2)+'\n')
 assert code==0
finally:
 if proc.poll() is None:
  proc.terminate()
  try:proc.wait(timeout=5)
  except subprocess.TimeoutExpired:proc.kill();proc.wait()
 os.close(master);(out/'debugger.txt').write_bytes(ANSI.sub(b'',bytes(raw)));(out/'debugger.raw').write_bytes(raw)
