"""Independent assertions over retained debugger observations; no emulator launch."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[3];base=ROOT/'.emulator/mos02';dest=base/'baseline-verification';dest.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def reg(e,name):return int(re.search(name+r':([0-9a-fA-F]+)',e['registers'])[1],16)
summary=[]
original=(base/'control-base.img').read_bytes()
for mode in ['stock','normal','busy','reject']:
 d=json.loads((base/mode/'result.json').read_text());assert d['exit_code']==0
 points={int(e['pc'],16):e for e in d['events'] if 'pc' in e}
 expected=1 if mode=='reject' else 0
 assert reg(points[0xa2eb],'AF')>>8==0 # CMD24 accepted
 assert reg(points[0xa379],'AF')>>8==0 # original command response restored
 assert reg(points[0xa2d2],'AF')>>8==expected
 assert reg(points[0xa770],'HL')==expected
 assert next(e['result'][0] for e in d['events'] if 'result' in e)==expected
 token=points[0xa379]['frame'][2];assert token==(255 if mode=='reject' else 5)
 assert (0xa366 in points)==(mode=='busy')
 assert (0xa368 in points)==(mode in ['normal','stock'])
 if mode=='busy':assert reg(points[0xa366],'AF')&1 # timer-expiry carry, no forced timer
 if mode!='reject':assert points[0xa341]['frame'][2]==5
 image=(base/mode/'sd.img').read_bytes()
 assert len(image)==len(original)
 assert image[:512]==original[:512] and image[1024:]==original[1024:]
 assert image[512:1024]==bytes((i*37+11)&255 for i in range(512))
 text=(base/mode/'debugger.txt').read_text()
 if mode!='stock':
  assert 'CMD24 sector=1 command_response=00' in text
  assert ('token=0d' if mode=='reject' else 'token=05') in text
 if mode=='busy':assert 'value=00 persistent_busy=true' in text
 summary.append({'mode':mode,'command_response':0,'retained_token':token,'busy_timeout_taken':0xa366 in points,'sd_status':expected,'disk_result':expected,'image_changes':'only disposable sector 1; all modes wrote host image before response injection','result_sha256':sha(base/mode/'result.json'),'image_sha256':sha(base/mode/'sd.img')})
pins=json.loads((ROOT/'docs/tasks/MOS-02/pins.json').read_text())
pins.update(instrumented_emulator_sha256=sha(base/'emulator/target/release/fab-agon-emulator'),stock_emulator_sha256=sha(ROOT/'.emulator/fab-agon-emulator.bin'),probe_sha256=sha(ROOT/'corrections/SDF-002-F01/reproducer/probe/bin/sd-timeout-probe.bin'),probe_map_sha256=sha(ROOT/'corrections/SDF-002-F01/reproducer/probe/bin/sd-timeout-probe.map'),timer_source_sha256=sha(base/'emulator/agon-ez80-emulator/src/prt_timer.rs'),instrumentation_sha256=sha(ROOT/'corrections/SDF-002-F01/reproducer/spi_sdcard.instrumented.rs'))
assert sha(base/'emulator/agon-ez80-emulator/src/prt_timer.rs')==sha(Path('/home/smith/Agon/mystuff/AgonJukebox/.emulator/runtime/fab-1.2.4/agon-ez80-emulator/src/prt_timer.rs'))
assert sha(ROOT/'.emulator/firmware/mos_platform.bin')==pins['mos_sha256']
assert sha(ROOT/'.emulator/firmware/vdp_platform.so')==pins['vdp_sha256']
(dest/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(dest/'results.json').write_text(json.dumps({'reproduced_under_injection':True,'hardware_tested':False,'later_reads_or_sync_tested':False,'controls':summary,'pins':pins},indent=2)+'\n')
print('PASSED: stock/normal/busy/reject controls; busy timeout returns SD_SUCCESS and RES_OK; only disposable sector 1 changed.')
