"""Rebuild isolated F01 qualification inputs; refuses an existing trial root."""
from pathlib import Path
import os,subprocess,shutil,tarfile,io
ROOT=Path(__file__).resolve().parents[3];TASK=Path(__file__).resolve().parent
base=ROOT/'.emulator/mos02';base.mkdir(exist_ok=False)
source=Path('/home/smith/Agon/mystuff/AgonJukebox/.emulator/runtime/fab-1.2.4')
emulator=base/'emulator';emulator.mkdir()
data=subprocess.check_output(['git','-C',str(source),'archive','194a5e44c36a8bb886dae1741b01c6e7a1e5ede7'])
with tarfile.open(fileobj=io.BytesIO(data)) as archive:archive.extractall(emulator,filter='data')
shutil.copy2(TASK/'spi_sdcard.instrumented.rs',emulator/'agon-ez80-emulator/src/spi_sdcard.rs')
env=os.environ.copy();env.update(FORCE='1',LIBRARY_PATH='/home/smith/.local/lib')
with (base/'build.log').open('w') as log:
 subprocess.run(['/home/smith/.cargo/bin/cargo','build','--release','--locked','--offline'],cwd=emulator,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
profile=base/'profile';profile.mkdir();(profile/'sdcard').mkdir();(profile/'firmware').mkdir()
for name in ['fab-agon-emulator','.mos-release','.mos-release.sha256']:shutil.copy2(ROOT/'.emulator'/name,profile/name)
for name in ['mos_platform.bin','mos_platform.map']:
 for target in [profile/name,profile/'firmware'/name]:target.symlink_to((ROOT/'.emulator/firmware'/name).resolve())
(profile/'firmware/vdp_platform.so').symlink_to((ROOT/'.emulator/firmware/vdp_platform.so').resolve())
(profile/'fab-agon-emulator.bin').symlink_to(emulator/'target/release/fab-agon-emulator')
subprocess.run(['make','-C',str(TASK/'probe')],check=True)
subprocess.run([str(ROOT.parents[1]/'.venv/bin/python'),str(ROOT/'scripts/prepare_sd_image.py'),'--binary',str(TASK/'probe/bin/sd-timeout-probe.bin'),'--output',str(base/'control-base.img')],check=True)
