#!/usr/bin/env bash
set -euo pipefail
package_root=$(cd "$(dirname "$0")/.." && pwd)
fixture_build=${1:-"$package_root/build/fixture"}
[[ ! -e "$fixture_build" ]] || { echo 'Use a fresh output directory.' >&2; exit 1; }
mkdir -p "$fixture_build"
cp "$package_root/source/fixture/host.asm" "$package_root/source/fixture/cases.inc" "$package_root/source/fixture/host.linkcmd" "$fixture_build/"
cd "$fixture_build"
"$HOME/.local/bin/agon-zds" ez80asm -list -listmac -quiet -NOsdiopt -warn -debug -NOigcase -cpu:eZ80F92 host.asm
"$HOME/.local/bin/agon-zds" eZ80link @host.linkcmd
objcopy -I ihex -O binary --gap-fill 0 host.hex repair.bin
sha256sum repair.bin
