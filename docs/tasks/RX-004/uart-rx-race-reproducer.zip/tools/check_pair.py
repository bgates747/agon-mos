"""Check raw baseline/repaired fixture results independently of screen output."""
import json
from pathlib import Path
import sys
from analyze import analyze

if len(sys.argv) != 3:
    raise SystemExit('Usage: python3 tools/check_pair.py BEFORE/race.dat FIXED/race.dat')
before, fixed = [analyze(Path(p).read_bytes()) for p in sys.argv[1:]]
assert before['regression_passed'] and before['baseline_fault_captured']
assert fixed['regression_passed'] and fixed['repaired_without_rescue']
assert not any(c['rescued'] for c in fixed['cases'])
print(json.dumps(dict(passed=True, before=before, fixed=fixed), indent=2))
