"""Materialize an exact VDP source variant, verify it, then optionally build."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('variant', choices=('before', 'fixed', 'candidate'))
p.add_argument('--output', type=Path, required=True)
p.add_argument('--prepare-only', action='store_true')
p.add_argument('--pio', default='pio')
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
src = root / 'source/vdp'
meta = json.loads((src / 'manifests' / (a.variant + '.json')).read_text())
assert not a.output.exists(), 'Use a fresh output directory.'
shutil.copytree(src / 'common', a.output)
overlay = src / 'variants' / a.variant
if overlay.exists():
    shutil.copytree(overlay, a.output, dirs_exist_ok=True)
for name in meta['removed']:
    (a.output / name).unlink()
files = {str(f.relative_to(a.output)): f for f in a.output.rglob('*') if f.is_file()}
assert files.keys() == meta['files'].keys(), 'Unexpected or missing source files.'
for name, expected in meta['files'].items():
    assert hashlib.sha256(files[name].read_bytes()).hexdigest() == expected, name
print(f'Verified {len(files)} source files for {a.variant}.', flush=True)
if not a.prepare_only:
    subprocess.run([a.pio, 'run', '-d', str(a.output.resolve()), '-j', '6'], check=True)
